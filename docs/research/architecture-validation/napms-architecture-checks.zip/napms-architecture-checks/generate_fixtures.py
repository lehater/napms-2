"""Generate isolated variants of a small NAPMS decision projection."""
from copy import deepcopy
import json
from pathlib import Path

target = Path(__file__).resolve().parent / "fixtures"
target.mkdir(exist_ok=True)

baseline = {
    "ownership": [
        {"fact": "resource.endpoint.current-address", "context": "resource-catalogue", "mode": "owner"},
        {"fact": "resource.endpoint.current-address", "context": "policy-materialization", "mode": "reader"},
    ],
    "identity": [
        {"id": "N1-legacy-pair", "edition": "N1", "profile": "legacy", "status": "historical",
         "key": "ordered-deployment-pair"},
        {"id": "N2-exact-subject", "edition": "N2", "profile": "first-slice", "status": "accepted",
         "key": "ordered-deployment-pair+immutable-revision"},
    ],
    "maxEndpoints": 1,
    "nodes": {
        "resource.endpoint.max": {"dependents": ["policy.materialize"], "reviewedMax": 0},
        "policy.materialize": {"dependents": ["policy.export", "policy.match"], "reviewedMax": 1},
        "policy.export": {"dependents": [], "reviewedMax": 1},
        "policy.match": {"dependents": [], "reviewedMax": 1},
    },
    "authority": [
        {"id": "N1-security-request", "edition": "N1", "profile": "mvp", "status": "historical",
         "operation": "access.request", "phase": "admission", "scopes": "both"},
        {"id": "N2-request", "edition": "N2", "profile": "first-slice", "status": "accepted",
         "operation": "access.request", "phase": "admission", "scopes": "source"},
        {"id": "N2-export", "edition": "N2", "profile": "first-slice", "status": "accepted",
         "operation": "policy.export", "phase": "read", "scopes": "both"},
    ],
    "lifecycle": {"withdrawalRequired": False, "userTransitions": ["request", "allow", "deny"]},
}
fixtures = {"baseline": baseline}
for name in ("a", "a-split-facts", "b", "b-new-profile", "b-replaces-record", "c", "c-no-edge", "c-third-hop", "c-reviewed",
             "d", "d-other-phase", "d-n1-audit", "e", "e-defined"):
    fixtures[name] = deepcopy(baseline)
fixtures["a"]["ownership"][1]["mode"] = "owner"
fixtures["a-split-facts"]["ownership"][1].update(fact="policy.materialization.row", mode="owner")
pair_proposal = dict(baseline["identity"][1], id="proposal-pair", status="proposed",
                     key="ordered-deployment-pair")
fixtures["b"]["identity"].append(pair_proposal)
fixtures["b-new-profile"]["identity"].append(dict(pair_proposal, profile="future-v3"))
fixtures["b-replaces-record"]["identity"][1]["key"] = "ordered-deployment-pair"
fixtures["c"]["maxEndpoints"] = 2
fixtures["c-no-edge"]["maxEndpoints"] = 2
fixtures["c-no-edge"]["nodes"]["policy.materialize"]["dependents"].remove("policy.match")
fixtures["c-third-hop"]["maxEndpoints"] = 2
fixtures["c-third-hop"]["nodes"]["policy.export"]["dependents"].append("policy.export.consumer")
fixtures["c-third-hop"]["nodes"]["policy.export.consumer"] = {"dependents": [], "reviewedMax": 1}
fixtures["c-reviewed"]["maxEndpoints"] = 2
for component in ("policy.export", "policy.match", "policy.materialize"):
    fixtures["c-reviewed"]["nodes"][component]["reviewedMax"] = 2
both_proposal = dict(baseline["authority"][1], id="proposal-both", status="proposed", scopes="both")
fixtures["d"]["authority"].append(both_proposal)
fixtures["d-other-phase"]["authority"].append(dict(both_proposal, phase="reauthorization"))
fixtures["d-n1-audit"]["authority"][0]["status"] = "accepted"
fixtures["d-n1-audit"]["authority"].append(
    dict(baseline["authority"][1], id="N1-system-request", edition="N1", profile="mvp")
)
fixtures["e"]["lifecycle"]["withdrawalRequired"] = True
fixtures["e-defined"]["lifecycle"]["withdrawalRequired"] = True
fixtures["e-defined"]["lifecycle"]["userTransitions"].append("withdraw")
for name, model in fixtures.items():
    (target / f"{name}.json").write_text(json.dumps({"model": model}, indent=2) + "\n")
