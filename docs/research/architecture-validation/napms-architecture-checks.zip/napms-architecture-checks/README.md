# NAPMS 2.0 — воспроизводимые проверки архитектурной модели

В комплекте одна проекция решений и две реализации правил. Входы A–E отражают примеры из NAPMS. Мутации синтетические. Для проверки Python используется неизменённый код NAPMS 2.0 `9713c89bada6573bda2f60c97fb45deda48f5909` и одноразовая копия с одним добавленным импортом.

## Проверка моделей

Испытано на Linux x86_64 с Python 3.12.14, [CUE 0.14.2](https://github.com/cue-lang/cue/releases/tag/v0.14.2) и [OPA 1.9.0](https://github.com/open-policy-agent/opa/releases/tag/v1.9.0). Используйте эти версии для точного повторения и запустите из этого каталога.

```sh
python3 generate_fixtures.py
python3 verify.py > observed-results.json
```

Пути к бинарникам можно задать переменными `CUE_BIN` и `OPA_BIN`. Сохранённые результаты опыта — `results.json`. Скрипт проверяет диагностические коды, объекты, согласие двух движков там, где ожидаются одинаковые результаты, и статусы выхода.

Ручной запуск на изменённой кардинальности, который должен перечислить materialization, export и matching.

```sh
cue vet -c rules.cue fixtures/c.json
cue export rules.cue fixtures/c.json -e diagnostics

opa check --strict rules.rego
opa eval --format raw --data rules.rego --input fixtures/c.json \
  'data.napms.architecture.diagnostics'
```

Отдельные команды для проверки статуса выхода на валидных входах. Замените `a.json` на `baseline.json` для проходящего контроля.

```sh
cue vet -c rules.cue gate.cue fixtures/a.json
opa eval --fail-defined --format raw --data rules.rego --input fixtures/a.json \
  'data.napms.architecture.diagnostics[_]'
```

Обе команды дают exit 1 на A. Пустой JSON демонстрирует, что этот Rego gate отдельно от проверки входа даёт exit 0. В CI этот gate требует валидации схемы и проверки, что вход охватывает ожидаемые решения. CUE-пример обходит максимум два ребра. В Rego используется `graph.reachable`. Оба движка опираются на объявленные рёбра и не находят пропущенный из входа edge.

## Проверка Python

Нужен локальный клон `lehater/napms-2`, в котором есть зафиксированный коммит. Переменная `NAPMS_REPO` указывает на него. Из этого каталога выполните команды в Linux/WSL2. Результат baseline ожидается с кодом 0, результат мутации с кодом 1. Команды используют временный каталог.

```sh
baseline=9713c89bada6573bda2f60c97fb45deda48f5909
demo_dir=$(mktemp -d)
mkdir -p "$demo_dir/baseline"
git -C "$NAPMS_REPO" archive "$baseline" src/napms | tar -x -C "$demo_dir/baseline"
cp -R "$demo_dir/baseline" "$demo_dir/mutant"
printf '\nfrom .http import COLUMNS\n' >> "$demo_dir/mutant/src/napms/domain.py"

python3 -m venv "$demo_dir/venv"
"$demo_dir/venv/bin/pip" install import-linter==2.6 grimp==3.13
PYTHONPATH="$demo_dir/baseline/src" "$demo_dir/venv/bin/lint-imports" --config importlinter.ini --no-cache
PYTHONPATH="$demo_dir/mutant/src" "$demo_dir/venv/bin/lint-imports" --config importlinter.ini --no-cache
```

Сохранённый вывод — `python-import-results.txt`. Мутант нарушает D1 напрямую через `domain → http` и транзитивно через `http → dev → storage`.
