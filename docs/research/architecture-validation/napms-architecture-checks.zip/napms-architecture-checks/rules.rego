package napms.architecture

import rego.v1

model := input.model

diagnostics contains d if {
	some i, j
	a := model.ownership[i]
	b := model.ownership[j]
	i < j
	a.fact == b.fact
	a.context != b.context
	a.mode == "owner"
	b.mode == "owner"
	d := {"code": "A_OWNER_CONFLICT", "subject": a.fact, "refs": [a.context, b.context]}
}

diagnostics contains d if {
	some i, j
	a := model.identity[i]
	b := model.identity[j]
	i < j
	a.status != "historical"
	b.status != "historical"
	[a.edition, a.profile] == [b.edition, b.profile]
	a.key != b.key
	d := {"code": "B_IDENTITY_CONFLICT", "subject": concat("/", [a.edition, a.profile, "PolicyRule"]), "refs": [a.id, b.id]}
}

edges := {id: node.dependents | some id, node in model.nodes}

diagnostics contains d if {
	root := "resource.endpoint.max"
	some id in graph.reachable(edges, {root})
	id != root
	model.nodes[id].reviewedMax != model.maxEndpoints
	d := {"code": "C_STALE_REVIEW", "subject": id, "refs": [root]}
}

diagnostics contains d if {
	some i, j
	a := model.authority[i]
	b := model.authority[j]
	i < j
	a.status != "historical"
	b.status != "historical"
	[a.edition, a.profile, a.operation, a.phase] == [b.edition, b.profile, b.operation, b.phase]
	a.scopes != b.scopes
	d := {"code": "D_AUTHORITY_CONFLICT", "subject": concat("/", [a.edition, a.profile, a.operation, a.phase]), "refs": [a.id, b.id]}
}

diagnostics contains d if {
	model.lifecycle.withdrawalRequired
	not "withdraw" in model.lifecycle.userTransitions
	d := {"code": "E_WITHDRAWAL_MISSING", "subject": "PolicyRule", "refs": ["userTransitions"]}
}
