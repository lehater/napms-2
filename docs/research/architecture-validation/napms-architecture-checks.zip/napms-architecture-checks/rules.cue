import "list"

#Status: "accepted" | "proposed" | "historical"
#Model: {
	ownership: [...{
		fact:    string
		context: string
		mode:    "owner" | "reader"
	}]
	identity: [...{
		id:      string
		edition: string
		profile: string
		status:  #Status
		key:     "ordered-deployment-pair" | "ordered-deployment-pair+immutable-revision"
	}]
	maxEndpoints: int & >=1
	nodes: {
		"resource.endpoint.max": #Node
		[string]:                #Node
	}
	authority: [...{
		id:        string
		edition:   string
		profile:   string
		status:    #Status
		operation: string
		phase:     string
		scopes:    "source" | "both"
	}]
	lifecycle: {
		withdrawalRequired: bool
		userTransitions: [...string]
	}
}
#Node: {dependents: [...string], reviewedMax: int & >=0}

model:   #Model
_root:   "resource.endpoint.max"
_direct: model.nodes[_root].dependents
// The PoC follows two edges at most. A third-hop test records the coverage difference.
_second: [for id in _direct for next in model.nodes[id].dependents {next}]
_impacted: list.Concat([_direct, _second])

diagnostics: [
	for i, a in model.ownership for j, b in model.ownership
	if i < j && a.fact == b.fact && a.context != b.context && a.mode == "owner" && b.mode == "owner" {
		code:    "A_OWNER_CONFLICT"
		subject: a.fact
		refs: [a.context, b.context]
	},
	for i, a in model.identity for j, b in model.identity
	if i < j && a.status != "historical" && b.status != "historical" &&
		a.edition == b.edition && a.profile == b.profile && a.key != b.key {
		code:    "B_IDENTITY_CONFLICT"
		subject: "\(a.edition)/\(a.profile)/PolicyRule"
		refs: [a.id, b.id]
	},
	for id, node in model.nodes
	if id != _root && list.Contains(_impacted, id) && node.reviewedMax != model.maxEndpoints {
		code:    "C_STALE_REVIEW"
		subject: id
		refs: [_root]
	},
	for i, a in model.authority for j, b in model.authority
	if i < j && a.status != "historical" && b.status != "historical" &&
		a.edition == b.edition && a.profile == b.profile && a.operation == b.operation &&
		a.phase == b.phase && a.scopes != b.scopes {
		code:    "D_AUTHORITY_CONFLICT"
		subject: "\(a.edition)/\(a.profile)/\(a.operation)/\(a.phase)"
		refs: [a.id, b.id]
	},
	if model.lifecycle.withdrawalRequired && !list.Contains(model.lifecycle.userTransitions, "withdraw") {
		code:    "E_WITHDRAWAL_MISSING"
		subject: "PolicyRule"
		refs: ["userTransitions"]
	},
]
