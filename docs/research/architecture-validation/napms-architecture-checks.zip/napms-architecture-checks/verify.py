"""Run both CLIs, compare diagnostics, and record exit codes for the controls."""
import json
import os
from pathlib import Path
import subprocess

os.chdir(Path(__file__).resolve().parent)
cue = os.environ.get("CUE_BIN", "cue")
opa = os.environ.get("OPA_BIN", "opa")
query = "data.napms.architecture.diagnostics"

impact = {"policy.materialize", "policy.export", "policy.match"}
expected = {
    "baseline": ("", set()),
    "a": ("A_OWNER_CONFLICT", {"resource.endpoint.current-address"}),
    "a-split-facts": ("", set()),
    "b": ("B_IDENTITY_CONFLICT", {"N2/first-slice/PolicyRule"}),
    "b-new-profile": ("", set()),
    "b-replaces-record": ("", set()),
    "c": ("C_STALE_REVIEW", impact),
    "c-no-edge": ("C_STALE_REVIEW", impact - {"policy.match"}),
    "c-third-hop": ("C_STALE_REVIEW", impact),
    "c-reviewed": ("", set()),
    "d": ("D_AUTHORITY_CONFLICT", {"N2/first-slice/access.request/admission"}),
    "d-other-phase": ("", set()),
    "d-n1-audit": ("D_AUTHORITY_CONFLICT", {"N1/mvp/access.request/admission"}),
    "e": ("E_WITHDRAWAL_MISSING", {"PolicyRule"}),
    "e-defined": ("", set()),
}

def run(*args):
    return subprocess.run(args, check=False, text=True, capture_output=True)

def require(result, expected_exit):
    if result.returncode != expected_exit:
        raise RuntimeError(
            f"{result.args} exit={result.returncode}, expected {expected_exit}\n"
            f"{result.stdout}{result.stderr}"
        )
    return result.stdout

report = {}
require(run(opa, "check", "--strict", "rules.rego"), 0)
for case, (code, subjects) in expected.items():
    source = f"fixtures/{case}.json"
    require(run(cue, "vet", "-c", "rules.cue", source), 0)
    cue_rows = json.loads(require(run(cue, "export", "rules.cue", source, "-e", "diagnostics"), 0))
    opa_args = (opa, "eval", "--format", "raw", "--data", "rules.rego", "--input", source)
    opa_rows = json.loads(require(run(*opa_args, query), 0))
    opa_subjects = subjects | {"policy.export.consumer"} if case == "c-third-hop" else subjects
    assert {(d["code"], d["subject"]) for d in cue_rows} == {(code, s) for s in subjects}, case
    assert {(d["code"], d["subject"]) for d in opa_rows} == {(code, s) for s in opa_subjects}, case
    if case != "c-third-hop":
        assert sorted(cue_rows, key=lambda d: d["subject"]) == sorted(
            opa_rows, key=lambda d: d["subject"]
        ), case
    require(run(cue, "vet", "-c", "rules.cue", "gate.cue", source), int(bool(subjects)))
    require(run(*opa_args, "--fail-defined", query + "[_]"), int(bool(opa_subjects)))
    report[case] = {
        "cue": cue_rows, "opa": opa_rows,
        "cue_gate_exit": int(bool(subjects)), "opa_gate_exit": int(bool(opa_subjects)),
    }
empty = "fixtures/empty-input.json"
empty_cue = run(cue, "vet", "-c", "rules.cue", "gate.cue", empty)
require(empty_cue, 1)
require(run(opa, "eval", "--fail-defined", "--data", "rules.rego", "--input", empty, query + "[_]"), 0)
report["empty-input"] = {"cue_gate_exit": 1, "opa_gate_exit": 0}
print(json.dumps(report, indent=2, ensure_ascii=False))
